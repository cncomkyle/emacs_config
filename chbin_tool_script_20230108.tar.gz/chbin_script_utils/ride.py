#!/bin/bash

export VERSIONER_PYTHON_PREFER_32_BIT=yes

ride.py
