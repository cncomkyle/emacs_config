function java_gen_toString()
{
    printf "to do \n"
}
